function getCart() {
  return JSON.parse(localStorage.getItem("cart") || "[]");
}

function saveCart(cart) {
  localStorage.setItem("cart", JSON.stringify(cart));
}

function addToCart(product) {

  const token = localStorage.getItem("token");

  if (!token) {

    // اگر Toast وجود ندارد، بساز
    let toast = document.getElementById("toast-login");

    if (!toast) {

      toast = document.createElement("div");
      toast.id = "toast-login";

      toast.style.cssText = `
                position:fixed;
                bottom:25px;
                right:25px;
                background:#dc2626;
                color:#fff;
                padding:14px 18px;
                border-radius:12px;
                box-shadow:0 10px 30px rgba(0,0,0,.2);
                font-size:14px;
                z-index:999999;
                opacity:0;
                transform:translateY(20px);
                transition:.3s;
            `;

      document.body.appendChild(toast);
    }

    toast.innerText = "ابتدا وارد حساب کاربری شوید";

    toast.style.opacity = "1";
    toast.style.transform = "translateY(0)";

    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(20px)";
    }, 1800);

    setTimeout(() => {
      window.location.href = "login.html";
    }, 1800);

    return;
  }

  const cart = getCart();

  const existing = cart.find(item => item._id === product._id);

  // سقف تعداد = موجودی انبار
  const maxQty = typeof product.stock === "number" ? product.stock : Infinity;

  if (maxQty <= 0 || (existing && existing.qty >= maxQty)) {
    if (window.showAppToast) window.showAppToast("به سقف موجودی این محصول رسیدید", "warning");
    return false;
  }

  if (existing) {
    existing.qty += 1;
    existing.stock = product.stock;
  } else {
    cart.push({ ...product, qty: 1 });
  }

  saveCart(cart);

  updateCartBadge();
  return true;
}

function removeFromCart(productId) {
  let cart = getCart();
  cart = cart.filter(item => item._id !== productId);
  saveCart(cart);
  if (document.querySelector(".cart-items-wrap")) renderBasket();
  updateCartBadge();
}

function clearCart() {
  saveCart([]);
  if (document.querySelector(".cart-items-wrap")) renderBasket();
  updateCartBadge();
}

function changeQty(productId, delta) {
  const cart = getCart();
  const item = cart.find(i => i._id === productId);
  if (!item) return;
  if (delta > 0 && typeof item.stock === "number" && item.qty + delta > item.stock) {
    if (window.showAppToast) window.showAppToast("به سقف موجودی این محصول رسیدید", "warning");
    return;
  }
  item.qty += delta;
  if (item.qty <= 0) {
    removeFromCart(productId);
    return;
  }
  saveCart(cart);
  if (document.querySelector(".cart-items-wrap")) renderBasket();
  updateCartBadge();
}

function formatPrice(p) {
  return p.toLocaleString("fa-IR");
}

function updateCartBadge() {
  const cart = getCart();
  const total = cart.reduce((sum, i) => sum + i.qty, 0);
  const badges = document.querySelectorAll(".cart-badge");
  badges.forEach(b => {
    b.textContent = total;
    b.style.display = total > 0 ? "flex" : "none";
  });
}

function renderBasket() {
  const cart = getCart();
  const emptyBasketWrap = document.querySelector(".empty-basket-wraper");
  const emptyState = document.getElementById("emptyState");
  const fullBasket = document.querySelector(".full-basket");
  const cartItemsWrap = document.querySelector(".cart-items-wrap");

  if (!cartItemsWrap) return;

  if (cart.length === 0) {
    if (emptyBasketWrap) emptyBasketWrap.style.display = "block";
    if (emptyState) emptyState.style.display = "flex";
    if (fullBasket) fullBasket.style.display = "none";
    return;
  }

  if (emptyBasketWrap) emptyBasketWrap.style.display = "none";
  if (emptyState) emptyState.style.display = "none";
  if (fullBasket) fullBasket.style.display = "block";

  const existingItems = cartItemsWrap.querySelectorAll(".cart-item");
  existingItems.forEach(el => el.remove());

  const couponBox = cartItemsWrap.querySelector(".coupon-box");

  cart.forEach(item => {
    const hasDiscount = item.discountPercent > 0;
    const finalPrice = hasDiscount
      ? Math.round(item.price * (1 - item.discountPercent / 100))
      : item.price;
    const totalPrice = finalPrice * item.qty;
    const imageUrl = item.image
      ? `https://api.narmcenter.com/${item.image.replace(/^\/?/, "")}`
      : "";
    const div = document.createElement("div");
    div.className = "cart-item";
    div.dataset.id = item._id;
    div.style.cursor = "pointer";

    div.addEventListener("click", () => {
      window.location.href = `cart.html?id=${item._id}`;
    });

    div.innerHTML = `
      <div class="item-img" style="background-image: url('${imageUrl}'); background-size: contain; background-repeat: no-repeat; background-position: center;"></div>
      <div class="item-info">
        <h4>${item.name}</h4>
        <div class="item-cat">بهداشتی</div>
        <div class="item-unit">هر بسته ${formatPrice(finalPrice)} تومان</div>
      </div>
      <div class="item-qty">
        <button class="qty-btn" onclick="event.stopPropagation(); changeQty('${item._id}', -1)" >−</button>
        <span class="qty-num">${item.qty}</span>
        <button class="qty-btn" ${typeof item.stock === "number" && item.qty >= item.stock ? "disabled" : ""} onclick="event.stopPropagation(); changeQty('${item._id}', 1)">+</button>
      </div>
      <div class="item-price">
        <span class="price">${formatPrice(totalPrice)}</span>
        <span class="unit-price">تومان</span>
      </div>
      <button class="item-remove" onclick="event.stopPropagation(); removeFromCart('${item._id}')" title="حذف">✕</button>
    `;

    if (couponBox) {
      cartItemsWrap.insertBefore(div, couponBox);
    } else {
      cartItemsWrap.appendChild(div);
    }
  });

  renderSummary(cart);
  updateCartTitle();
}

function renderSummary(cart) {
  const shipping = 35000;
  const subtotal = cart.reduce((sum, item) => {
    const hasDiscount = item.discountPercent > 0;
    const finalPrice = hasDiscount
      ? Math.round(item.price * (1 - item.discountPercent / 100))
      : item.price;
    return sum + finalPrice * item.qty;
  }, 0);

  const discount = cart.reduce((sum, item) => {
    if (item.discountPercent > 0) {
      const saved = Math.round(item.price * (item.discountPercent / 100));
      return sum + saved * item.qty;
    }
    return sum;
  }, 0);

  const freeShipping = subtotal >= 500000;
  const shippingCost = freeShipping ? 0 : shipping;
  const total = subtotal + shippingCost;

  const rows = document.querySelectorAll(".summary-row .value");
  if (rows[0]) rows[0].textContent = formatPrice(subtotal) + " تومان";
  if (rows[1]) rows[1].textContent = freeShipping ? "رایگان" : formatPrice(shippingCost) + " تومان";
  if (rows[2]) rows[2].textContent = discount > 0 ? `— ${formatPrice(discount)} تومان` : "—";

  const totalEl = document.querySelector(".summary-total .value");
  if (totalEl) totalEl.innerHTML = `${formatPrice(total)}<small>تومان</small>`;

  // نوار شناور موبایل + پنجره‌ی جزئیات پرداخت
  const count = cart.reduce((n, i) => n + i.qty, 0);
  const setT = (id, t) => { const el = document.getElementById(id); if (el) el.textContent = t; };
  setT("sumToggleText", `جمع ${count} کالا`);
  setT("sheetCountLabel", `مجموع قیمت کالاها (${count} کالا)`);
  setT("sheetSubtotal", formatPrice(subtotal) + " تومان");
  setT("sheetShipping", freeShipping ? "رایگان" : formatPrice(shippingCost) + " تومان");
  setT("sheetDiscount", discount > 0 ? `— ${formatPrice(discount)} تومان` : "—");
  setT("sheetTotal", formatPrice(total) + " تومان");
}

function updateCartTitle() {
  const cart = getCart();
  const total = cart.reduce((sum, i) => sum + i.qty, 0);
  const title = document.getElementById("cart-count-title");
  if (title) title.textContent = `محصولات (${total} عدد)`;
}

const clearBtn = document.querySelector(".clear-btn");
if (clearBtn) {
  clearBtn.addEventListener("click", () => {
    if (confirm("همه محصولات از سبد حذف شوند؟")) clearCart();
  });
}

document.addEventListener("DOMContentLoaded", () => {
  renderBasket();
  updateCartBadge();
  refreshCartStock();
});

// موجودی فعلی محصولات داخل سبد را از سرور می‌گیرد (فقط در صفحه سبد)
// تا تعداد هر کالا بیشتر از موجودی انبار نماند.
async function refreshCartStock() {
  if (!document.querySelector(".cart-items-wrap")) return;
  const cart = getCart();
  if (!cart.length) return;

  let changed = false;
  let trimmed = false;

  await Promise.all(cart.map(async (item) => {
    try {
      const res = await fetch(`https://api.narmcenter.com/api/products/${item._id}`);
      if (!res.ok) return;
      const fresh = await res.json();
      if (!fresh || typeof fresh.stock !== "number") return;
      if (item.stock !== fresh.stock) { item.stock = fresh.stock; changed = true; }
      if (fresh.stock > 0 && item.qty > fresh.stock) { item.qty = fresh.stock; changed = true; trimmed = true; }
    } catch (e) { /* خطای شبکه: همان موجودی ذخیره‌شده می‌ماند */ }
  }));

  const outOfStock = cart.filter(i => typeof i.stock === "number" && i.stock <= 0);
  const finalCart = cart.filter(i => !(typeof i.stock === "number" && i.stock <= 0));

  if (!changed && !outOfStock.length) return;
  saveCart(finalCart);
  renderBasket();
  updateCartBadge();

  if (window.showAppToast) {
    if (outOfStock.length) window.showAppToast("بعضی کالاها ناموجود شدند و از سبد حذف شدند", "warning");
    else if (trimmed) window.showAppToast("تعداد بعضی کالاها با موجودی انبار تنظیم شد", "warning");
  }
}

// باز و بسته شدن پنجره‌ی جزئیات پرداخت (موبایل)
document.addEventListener("DOMContentLoaded", function () {
  const sheet = document.getElementById("sumSheet");
  const back = document.getElementById("sumBackdrop");
  const toggle = document.getElementById("sumToggle");
  if (!sheet || !back || !toggle) return;
  const setOpen = (open) => {
    sheet.classList.toggle("is-open", open);
    back.classList.toggle("is-open", open);
    sheet.setAttribute("aria-hidden", String(!open));
    toggle.setAttribute("aria-expanded", String(open));
  };
  toggle.addEventListener("click", () => setOpen(!sheet.classList.contains("is-open")));
  back.addEventListener("click", () => setOpen(false));
  document.getElementById("sumClose").addEventListener("click", () => setOpen(false));
  document.getElementById("sumOk").addEventListener("click", () => setOpen(false));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") setOpen(false); });
  window.addEventListener("resize", () => { if (window.innerWidth > 1024) setOpen(false); });
});
