const params = new URLSearchParams(window.location.search);

const refId = params.get("refId");

const refElement = document.getElementById("refId");

if (refId) {

    refElement.innerHTML = `
        <span>کد رهگیری :</span>
        <strong>${refId}</strong>
    `;

} else {

    refElement.style.display = "none";

}